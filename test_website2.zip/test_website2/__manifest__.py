{
    'name':' e website',
    'version' : '1.2',
    'summary': 'HMS',
    'sequence': 10,
    'category': 'Support website',
    'images' : [],
    'depends' : [],
    'data': [
    ],
}