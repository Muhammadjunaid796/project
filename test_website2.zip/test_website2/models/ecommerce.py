from odoo import api, fields, models

class websiteecommerce(models.Model):
    _name = 'ecommerce.website'
    _description = 'ecommerce web'