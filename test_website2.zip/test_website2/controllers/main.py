from odoo import http


class website(http.Controller):
    @http.route('/hospital/patient/',website=True, auth='public')
    def front_website(self,**kw):
        return "hello world"